-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 21 2017 г., 17:03
-- Версия сервера: 5.6.31
-- Версия PHP: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `klunker`
--

-- --------------------------------------------------------

--
-- Структура таблицы `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Мистер WordPress', '', 'https://wordpress.org/', '', '2016-03-02 15:38:51', '2016-03-02 12:38:51', 'Привет! Это комментарий.\nЧтобы удалить его, авторизуйтесь и просмотрите комментарии к записи. Там будут ссылки для их изменения или удаления.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://klunkerlocal.ru/site', 'yes'),
(2, 'home', 'http://klunkerlocal.ru', 'yes'),
(3, 'blogname', 'Klunker', 'yes'),
(4, 'blogdescription', 'Ещё один сайт на WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'alexander.palshin@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'hack_file', '0', 'yes'),
(30, 'blog_charset', 'UTF-8', 'yes'),
(31, 'moderation_keys', '', 'no'),
(32, 'active_plugins', 'a:2:{i:0;s:61:"orbisius-child-theme-creator/orbisius-child-theme-creator.php";i:1;s:45:"search-and-replace/inpsyde-search-replace.php";}', 'yes'),
(33, 'category_base', '', 'yes'),
(34, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(35, 'comment_max_links', '2', 'yes'),
(36, 'gmt_offset', '3', 'yes'),
(37, 'default_email_category', '1', 'yes'),
(38, 'recently_edited', '', 'no'),
(39, 'template', 'twentysixteen', 'yes'),
(40, 'stylesheet', 'klunker', 'yes'),
(41, 'comment_whitelist', '1', 'yes'),
(42, 'blacklist_keys', '', 'no'),
(43, 'comment_registration', '0', 'yes'),
(44, 'html_type', 'text/html', 'yes'),
(45, 'use_trackback', '0', 'yes'),
(46, 'default_role', 'subscriber', 'yes'),
(47, 'db_version', '35700', 'yes'),
(48, 'uploads_use_yearmonth_folders', '1', 'yes'),
(49, 'upload_path', '', 'yes'),
(50, 'blog_public', '1', 'yes'),
(51, 'default_link_category', '2', 'yes'),
(52, 'show_on_front', 'page', 'yes'),
(53, 'tag_base', '', 'yes'),
(54, 'show_avatars', '1', 'yes'),
(55, 'avatar_rating', 'G', 'yes'),
(56, 'upload_url_path', '', 'yes'),
(57, 'thumbnail_size_w', '150', 'yes'),
(58, 'thumbnail_size_h', '150', 'yes'),
(59, 'thumbnail_crop', '1', 'yes'),
(60, 'medium_size_w', '300', 'yes'),
(61, 'medium_size_h', '300', 'yes'),
(62, 'avatar_default', 'mystery', 'yes'),
(63, 'large_size_w', '1024', 'yes'),
(64, 'large_size_h', '1024', 'yes'),
(65, 'image_default_link_type', 'none', 'yes'),
(66, 'image_default_size', '', 'yes'),
(67, 'image_default_align', '', 'yes'),
(68, 'close_comments_for_old_posts', '0', 'yes'),
(69, 'close_comments_days_old', '14', 'yes'),
(70, 'thread_comments', '1', 'yes'),
(71, 'thread_comments_depth', '5', 'yes'),
(72, 'page_comments', '0', 'yes'),
(73, 'comments_per_page', '50', 'yes'),
(74, 'default_comments_page', 'newest', 'yes'),
(75, 'comment_order', 'asc', 'yes'),
(76, 'sticky_posts', 'a:0:{}', 'yes'),
(77, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'uninstall_plugins', 'a:0:{}', 'no'),
(81, 'timezone_string', '', 'yes'),
(82, 'page_for_posts', '0', 'yes'),
(83, 'page_on_front', '23', 'yes'),
(84, 'default_post_format', '0', 'yes'),
(85, 'link_manager_enabled', '0', 'yes'),
(86, 'finished_splitting_shared_terms', '1', 'yes'),
(87, 'site_icon', '0', 'yes'),
(88, 'medium_large_size_w', '768', 'yes'),
(89, 'medium_large_size_h', '0', 'yes'),
(90, 'initial_db_version', '35700', 'yes'),
(91, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(92, 'WPLANG', 'ru_RU', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";N;s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:4:{i:1510792732;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1510835987;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1510836693;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(115, '_site_transient_timeout_browser_e3ae366e66d1c39ce6cf9f9706edbba9', '1457527153', 'yes'),
(116, '_site_transient_browser_e3ae366e66d1c39ce6cf9f9706edbba9', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"48.0.2564.116";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'),
(120, 'can_compress_scripts', '1', 'yes'),
(143, 'orbisius_child_theme_creator_options', 'a:4:{s:6:"status";i:1;s:10:"setup_time";i:1456922685;i:0;b:0;i:1;b:0;}', 'yes'),
(144, 'recently_activated', 'a:0:{}', 'yes'),
(147, 'current_theme', 'Klunker', 'yes'),
(148, 'theme_mods_twentysixteen-child-01', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1456922800;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";N;s:9:"sidebar-3";N;}}}', 'yes'),
(149, 'theme_switched', '', 'yes'),
(152, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1456922805;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(153, 'theme_mods_klunker', 'a:1:{i:0;b:0;}', 'yes'),
(174, '_site_transient_timeout_browser_2c7afd74200035be5fac3b47741b9a6e', '1511024673', 'yes'),
(175, '_site_transient_browser_2c7afd74200035be5fac3b47741b9a6e', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:12:"62.0.3202.89";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'yes'),
(232, 'category_children', 'a:0:{}', 'yes'),
(260, '_transient_is_multi_author', '0', 'yes'),
(270, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1510679571', 'no'),
(271, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1510679571', 'no'),
(272, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1510636371', 'no'),
(273, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1510679574', 'no'),
(274, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1510679574', 'no'),
(275, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1510636374', 'no'),
(276, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1510679579', 'no'),
(277, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1510679579', 'no'),
(278, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1510636379', 'no'),
(279, '_transient_timeout_plugin_slugs', '1510722892', 'no'),
(280, '_transient_plugin_slugs', 'a:4:{i:0;s:19:"akismet/akismet.php";i:1;s:9:"hello.php";i:2;s:61:"orbisius-child-theme-creator/orbisius-child-theme-creator.php";i:3;s:45:"search-and-replace/inpsyde-search-replace.php";}', 'no'),
(281, '_transient_timeout_dash_f69de0bbfe7eaa113146875f40c02000', '1510679579', 'no'),
(282, '_transient_dash_f69de0bbfe7eaa113146875f40c02000', '<div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wordpress.org/news/2017/11/wordpress-4-9-release-candidate-2/''>WordPress 4.9 Release Candidate 2</a> <span class="rss-date">07.11.2017</span><div class="rssSummary">The second release candidate for WordPress 4.9 is now available. A release candidate (RC) means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.9 on Tuesday, November 14 (just over one week from now), but we need your help [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=''rsswidget'' href=''https://wptavern.com/ia-writer-5-for-ios-released-web-collaboration-version-coming-soon''>WPTavern: iA Writer 5 for iOS Released, Web Collaboration Version Coming Soon</a></li><li><a class=''rsswidget'' href=''https://wptavern.com/watch-the-state-of-the-woo-after-you-give-woocommerce-your-name-and-email-address''>WPTavern: Watch the State of the Woo! After You Give WooCommerce Your Name and Email Address</a></li><li><a class=''rsswidget'' href=''https://ma.tt/2017/11/product-and-process/''>Matt: Product and Process</a></li></ul></div><div class="rss-widget"><ul><li class=''dashboard-news-plugin''><span>Популярный плагин:</span> <a href=''https://wordpress.org/plugins/limit-login-attempts/'' class=''dashboard-news-plugin-link''>Limit Login Attempts</a>&nbsp;<span>(<a href=''plugin-install.php?tab=plugin-information&amp;plugin=limit-login-attempts&amp;_wpnonce=f1eb9185b5&amp;TB_iframe=true&amp;width=600&amp;height=800'' class=''thickbox'' title=''Limit Login Attempts''>Установить</a>)</span></li></ul></div>', 'no'),
(283, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1510647186', 'yes'),
(284, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'O:8:"stdClass":100:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";i:4397;}s:4:"post";a:3:{s:4:"name";s:4:"post";s:4:"slug";s:4:"post";s:5:"count";i:2517;}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";i:2396;}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";i:2378;}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";i:1842;}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";i:1613;}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";i:1605;}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";i:1437;}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";i:1363;}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";i:1362;}s:8:"facebook";a:3:{s:4:"name";s:8:"facebook";s:4:"slug";s:8:"facebook";s:5:"count";i:1348;}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";i:1283;}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";i:1273;}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";i:1156;}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";i:1066;}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";i:1056;}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";i:1002;}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";i:966;}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";i:833;}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";i:830;}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";i:817;}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";i:782;}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";i:773;}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";i:680;}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";i:674;}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";i:670;}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";i:658;}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";i:658;}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";i:648;}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";i:642;}s:6:"slider";a:3:{s:4:"name";s:6:"slider";s:4:"slug";s:6:"slider";s:5:"count";i:636;}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";i:619;}s:9:"analytics";a:3:{s:4:"name";s:9:"analytics";s:4:"slug";s:9:"analytics";s:5:"count";i:610;}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";i:599;}s:4:"ajax";a:3:{s:4:"name";s:4:"ajax";s:4:"slug";s:4:"ajax";s:5:"count";i:591;}s:6:"search";a:3:{s:4:"name";s:6:"search";s:4:"slug";s:6:"search";s:5:"count";i:587;}s:10:"e-commerce";a:3:{s:4:"name";s:10:"e-commerce";s:4:"slug";s:10:"e-commerce";s:5:"count";i:586;}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";i:583;}s:4:"menu";a:3:{s:4:"name";s:4:"menu";s:4:"slug";s:4:"menu";s:5:"count";i:567;}s:4:"form";a:3:{s:4:"name";s:4:"form";s:4:"slug";s:4:"form";s:5:"count";i:567;}s:5:"embed";a:3:{s:4:"name";s:5:"embed";s:4:"slug";s:5:"embed";s:5:"count";i:551;}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";i:540;}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";i:528;}s:3:"css";a:3:{s:4:"name";s:3:"css";s:4:"slug";s:3:"css";s:5:"count";i:525;}s:5:"share";a:3:{s:4:"name";s:5:"share";s:4:"slug";s:5:"share";s:5:"count";i:512;}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";i:503;}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";i:503;}s:5:"theme";a:3:{s:4:"name";s:5:"theme";s:4:"slug";s:5:"theme";s:5:"count";i:493;}s:10:"responsive";a:3:{s:4:"name";s:10:"responsive";s:4:"slug";s:10:"responsive";s:5:"count";i:483;}s:9:"dashboard";a:3:{s:4:"name";s:9:"dashboard";s:4:"slug";s:9:"dashboard";s:5:"count";i:479;}s:6:"custom";a:3:{s:4:"name";s:6:"custom";s:4:"slug";s:6:"custom";s:5:"count";i:478;}s:10:"categories";a:3:{s:4:"name";s:10:"categories";s:4:"slug";s:10:"categories";s:5:"count";i:474;}s:6:"editor";a:3:{s:4:"name";s:6:"editor";s:4:"slug";s:6:"editor";s:5:"count";i:457;}s:3:"ads";a:3:{s:4:"name";s:3:"ads";s:4:"slug";s:3:"ads";s:5:"count";i:455;}s:9:"affiliate";a:3:{s:4:"name";s:9:"affiliate";s:4:"slug";s:9:"affiliate";s:5:"count";i:454;}s:6:"button";a:3:{s:4:"name";s:6:"button";s:4:"slug";s:6:"button";s:5:"count";i:448;}s:12:"contact-form";a:3:{s:4:"name";s:12:"contact form";s:4:"slug";s:12:"contact-form";s:5:"count";i:446;}s:4:"tags";a:3:{s:4:"name";s:4:"tags";s:4:"slug";s:4:"tags";s:5:"count";i:444;}s:4:"user";a:3:{s:4:"name";s:4:"user";s:4:"slug";s:4:"user";s:5:"count";i:425;}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";i:417;}s:6:"mobile";a:3:{s:4:"name";s:6:"mobile";s:4:"slug";s:6:"mobile";s:5:"count";i:414;}s:7:"contact";a:3:{s:4:"name";s:7:"contact";s:4:"slug";s:7:"contact";s:5:"count";i:413;}s:5:"users";a:3:{s:4:"name";s:5:"users";s:4:"slug";s:5:"users";s:5:"count";i:409;}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";i:408;}s:9:"slideshow";a:3:{s:4:"name";s:9:"slideshow";s:4:"slug";s:9:"slideshow";s:5:"count";i:407;}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";i:399;}s:3:"api";a:3:{s:4:"name";s:3:"api";s:4:"slug";s:3:"api";s:5:"count";i:390;}s:6:"events";a:3:{s:4:"name";s:6:"events";s:4:"slug";s:6:"events";s:5:"count";i:388;}s:10:"statistics";a:3:{s:4:"name";s:10:"statistics";s:4:"slug";s:10:"statistics";s:5:"count";i:386;}s:10:"navigation";a:3:{s:4:"name";s:10:"navigation";s:4:"slug";s:10:"navigation";s:5:"count";i:375;}s:4:"news";a:3:{s:4:"name";s:4:"news";s:4:"slug";s:4:"news";s:5:"count";i:358;}s:8:"calendar";a:3:{s:4:"name";s:8:"calendar";s:4:"slug";s:8:"calendar";s:5:"count";i:350;}s:7:"payment";a:3:{s:4:"name";s:7:"payment";s:4:"slug";s:7:"payment";s:5:"count";i:346;}s:10:"shortcodes";a:3:{s:4:"name";s:10:"shortcodes";s:4:"slug";s:10:"shortcodes";s:5:"count";i:344;}s:9:"multisite";a:3:{s:4:"name";s:9:"multisite";s:4:"slug";s:9:"multisite";s:5:"count";i:335;}s:12:"social-media";a:3:{s:4:"name";s:12:"social media";s:4:"slug";s:12:"social-media";s:5:"count";i:333;}s:5:"popup";a:3:{s:4:"name";s:5:"popup";s:4:"slug";s:5:"popup";s:5:"count";i:333;}s:7:"plugins";a:3:{s:4:"name";s:7:"plugins";s:4:"slug";s:7:"plugins";s:5:"count";i:331;}s:4:"code";a:3:{s:4:"name";s:4:"code";s:4:"slug";s:4:"code";s:5:"count";i:330;}s:10:"newsletter";a:3:{s:4:"name";s:10:"newsletter";s:4:"slug";s:10:"newsletter";s:5:"count";i:330;}s:4:"list";a:3:{s:4:"name";s:4:"list";s:4:"slug";s:4:"list";s:5:"count";i:325;}s:3:"url";a:3:{s:4:"name";s:3:"url";s:4:"slug";s:3:"url";s:5:"count";i:324;}s:4:"meta";a:3:{s:4:"name";s:4:"meta";s:4:"slug";s:4:"meta";s:5:"count";i:324;}s:9:"marketing";a:3:{s:4:"name";s:9:"marketing";s:4:"slug";s:9:"marketing";s:5:"count";i:318;}s:4:"chat";a:3:{s:4:"name";s:4:"chat";s:4:"slug";s:4:"chat";s:5:"count";i:314;}s:8:"redirect";a:3:{s:4:"name";s:8:"redirect";s:4:"slug";s:8:"redirect";s:5:"count";i:305;}s:6:"simple";a:3:{s:4:"name";s:6:"simple";s:4:"slug";s:6:"simple";s:5:"count";i:301;}s:15:"payment-gateway";a:3:{s:4:"name";s:15:"payment gateway";s:4:"slug";s:15:"payment-gateway";s:5:"count";i:301;}s:3:"tag";a:3:{s:4:"name";s:3:"tag";s:4:"slug";s:3:"tag";s:5:"count";i:298;}s:5:"forms";a:3:{s:4:"name";s:5:"forms";s:4:"slug";s:5:"forms";s:5:"count";i:297;}s:16:"custom-post-type";a:3:{s:4:"name";s:16:"custom post type";s:4:"slug";s:16:"custom-post-type";s:5:"count";i:296;}s:11:"advertising";a:3:{s:4:"name";s:11:"advertising";s:4:"slug";s:11:"advertising";s:5:"count";i:289;}s:7:"adsense";a:3:{s:4:"name";s:7:"adsense";s:4:"slug";s:7:"adsense";s:5:"count";i:287;}s:4:"html";a:3:{s:4:"name";s:4:"html";s:4:"slug";s:4:"html";s:5:"count";i:285;}s:6:"author";a:3:{s:4:"name";s:6:"author";s:4:"slug";s:6:"author";s:5:"count";i:283;}s:8:"lightbox";a:3:{s:4:"name";s:8:"lightbox";s:4:"slug";s:8:"lightbox";s:5:"count";i:281;}s:8:"tracking";a:3:{s:4:"name";s:8:"tracking";s:4:"slug";s:8:"tracking";s:5:"count";i:277;}s:12:"notification";a:3:{s:4:"name";s:12:"notification";s:4:"slug";s:12:"notification";s:5:"count";i:277;}s:7:"tinymce";a:3:{s:4:"name";s:7:"tinyMCE";s:4:"slug";s:7:"tinymce";s:5:"count";i:277;}s:16:"google-analytics";a:3:{s:4:"name";s:16:"google analytics";s:4:"slug";s:16:"google-analytics";s:5:"count";i:275;}}', 'yes'),
(287, '_site_transient_timeout_available_translations', '1510647331', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(288, '_site_transient_available_translations', 'a:79:{s:3:"ary";a:8:{s:8:"language";s:3:"ary";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-12 10:15:45";s:12:"english_name";s:15:"Moroccan Arabic";s:11:"native_name";s:31:"العربية المغربية";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/ary.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:3;s:3:"ary";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-07 13:09:53";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:3:"azb";a:8:{s:8:"language";s:3:"azb";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-11 22:42:10";s:12:"english_name";s:17:"South Azerbaijani";s:11:"native_name";s:29:"گؤنئی آذربایجان";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/azb.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:3;s:3:"azb";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-07 20:53:51";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 08:50:29";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:12:"Напред";}}s:5:"bn_BD";a:8:{s:8:"language";s:5:"bn_BD";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-08 13:17:04";s:12:"english_name";s:7:"Bengali";s:11:"native_name";s:15:"বাংলা";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/bn_BD.zip";s:3:"iso";a:1:{i:1;s:2:"bn";}s:7:"strings";a:1:{s:8:"continue";s:23:"এগিয়ে চল.";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-04 09:40:25";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-08 07:49:01";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:3:"ceb";a:8:{s:8:"language";s:3:"ceb";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-16 15:34:57";s:12:"english_name";s:7:"Cebuano";s:11:"native_name";s:7:"Cebuano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/ceb.zip";s:3:"iso";a:2:{i:2;s:3:"ceb";i:3;s:3:"ceb";}s:7:"strings";a:1:{s:8:"continue";s:7:"Padayun";}}s:5:"cs_CZ";a:8:{s:8:"language";s:5:"cs_CZ";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-11 18:32:36";s:12:"english_name";s:5:"Czech";s:11:"native_name";s:12:"Čeština‎";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/cs_CZ.zip";s:3:"iso";a:2:{i:1;s:2:"cs";i:2;s:3:"ces";}s:7:"strings";a:1:{s:8:"continue";s:11:"Pokračovat";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-26 16:01:40";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 22:48:20";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsæt";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-29 10:47:54";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-26 16:11:56";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.4.2/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-10 14:21:56";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:14:"de_CH_informal";a:8:{s:8:"language";s:14:"de_CH_informal";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-10 14:06:54";s:12:"english_name";s:30:"German (Switzerland, Informal)";s:11:"native_name";s:21:"Deutsch (Schweiz, Du)";s:7:"package";s:73:"https://downloads.wordpress.org/translation/core/4.4.2/de_CH_informal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-16 07:59:10";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_NZ";a:8:{s:8:"language";s:5:"en_NZ";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-26 02:01:14";s:12:"english_name";s:21:"English (New Zealand)";s:11:"native_name";s:21:"English (New Zealand)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/en_NZ.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-14 21:14:29";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-06 23:10:59";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_ZA";a:8:{s:8:"language";s:5:"en_ZA";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-15 11:52:35";s:12:"english_name";s:22:"English (South Africa)";s:11:"native_name";s:22:"English (South Africa)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/en_ZA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-07 04:39:48";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-25 13:07:29";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-07 17:35:10";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_VE";a:8:{s:8:"language";s:5:"es_VE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-13 06:14:13";s:12:"english_name";s:19:"Spanish (Venezuela)";s:11:"native_name";s:21:"Español de Venezuela";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_VE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-24 15:17:36";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CO";a:8:{s:8:"language";s:5:"es_CO";s:7:"version";s:6:"4.3-RC";s:7:"updated";s:19:"2015-08-04 06:10:33";s:12:"english_name";s:18:"Spanish (Colombia)";s:11:"native_name";s:20:"Español de Colombia";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.3-RC/es_CO.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-02 20:27:44";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_AR";a:8:{s:8:"language";s:5:"es_AR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-23 00:46:01";s:12:"english_name";s:19:"Spanish (Argentina)";s:11:"native_name";s:21:"Español de Argentina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_AR.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-13 12:28:49";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_GT";a:8:{s:8:"language";s:5:"es_GT";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-09 18:08:52";s:12:"english_name";s:19:"Spanish (Guatemala)";s:11:"native_name";s:21:"Español de Guatemala";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/es_GT.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-18 06:44:22";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-03 10:31:09";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-31 19:24:20";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-23 06:49:15";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-08 17:19:17";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_BE";a:8:{s:8:"language";s:5:"fr_BE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 13:47:35";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/fr_BE.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_CA";a:8:{s:8:"language";s:5:"fr_CA";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-09 02:16:19";s:12:"english_name";s:15:"French (Canada)";s:11:"native_name";s:19:"Français du Canada";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/fr_CA.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:6:"4.3.13";s:7:"updated";s:19:"2015-09-24 15:25:30";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3.13/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-13 16:48:03";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-05 00:59:09";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-16 18:59:27";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:8:"המשך";}}s:5:"hi_IN";a:8:{s:8:"language";s:5:"hi_IN";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-11 05:43:28";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/hi_IN.zip";s:3:"iso";a:2:{i:1;s:2:"hi";i:2;s:3:"hin";}s:7:"strings";a:1:{s:8:"continue";s:12:"जारी";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-04 08:39:26";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-03 14:37:42";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:10:"Folytatás";}}s:2:"hy";a:8:{s:8:"language";s:2:"hy";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-04 07:13:54";s:12:"english_name";s:8:"Armenian";s:11:"native_name";s:14:"Հայերեն";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/hy.zip";s:3:"iso";a:2:{i:1;s:2:"hy";i:2;s:3:"hye";}s:7:"strings";a:1:{s:8:"continue";s:20:"Շարունակել";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-21 16:17:50";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 00:20:24";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-26 11:33:44";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-11 02:48:55";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ka_GE";a:8:{s:8:"language";s:5:"ka_GE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-09 08:53:31";s:12:"english_name";s:8:"Georgian";s:11:"native_name";s:21:"ქართული";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ka_GE.zip";s:3:"iso";a:2:{i:1;s:2:"ka";i:2;s:3:"kat";}s:7:"strings";a:1:{s:8:"continue";s:30:"გაგრძელება";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-24 00:12:01";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 20:07:24";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"ms_MY";a:8:{s:8:"language";s:5:"ms_MY";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-28 05:41:39";s:12:"english_name";s:5:"Malay";s:11:"native_name";s:13:"Bahasa Melayu";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ms_MY.zip";s:3:"iso";a:2:{i:1;s:2:"ms";i:2;s:3:"msa";}s:7:"strings";a:1:{s:8:"continue";s:8:"Teruskan";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:6:"4.1.20";s:7:"updated";s:19:"2015-03-26 15:57:42";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ဆောင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-07 10:01:09";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-23 18:59:13";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:12:"nl_NL_formal";a:8:{s:8:"language";s:12:"nl_NL_formal";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-20 13:35:50";s:12:"english_name";s:14:"Dutch (Formal)";s:11:"native_name";s:20:"Nederlands (Formeel)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/4.4.2/nl_NL_formal.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-14 12:19:44";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-26 06:46:10";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.4.2/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-24 15:31:29";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:6:"4.1.20";s:7:"updated";s:19:"2015-03-29 22:19:48";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:19:"دوام ورکړه";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-03 17:32:29";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-20 19:55:09";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-05-05 12:59:44";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-21 18:23:26";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-26 11:29:13";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-11-26 00:00:18";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:8:"Nadaljuj";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-02-23 10:30:30";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-09 09:09:51";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-09 12:04:20";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-08 03:22:55";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-11-27 15:51:36";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-17 23:12:27";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:6:"4.1.20";s:7:"updated";s:19:"2015-03-26 16:45:38";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.1.20/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-01-03 22:04:41";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:2:"vi";a:8:{s:8:"language";s:2:"vi";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-09 01:01:25";s:12:"english_name";s:10:"Vietnamese";s:11:"native_name";s:14:"Tiếng Việt";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.4.2/vi.zip";s:3:"iso";a:2:{i:1;s:2:"vi";i:2;s:3:"vie";}s:7:"strings";a:1:{s:8:"continue";s:12:"Tiếp tục";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-04-12 09:17:17";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2015-12-12 22:55:08";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}}', 'yes'),
(294, 'rewrite_rules', 'a:99:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:8:"autos/?$";s:25:"index.php?post_type=autos";s:38:"autos/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=autos&feed=$matches[1]";s:33:"autos/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=autos&feed=$matches[1]";s:25:"autos/page/([0-9]{1,})/?$";s:43:"index.php?post_type=autos&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"autos/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"autos/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"autos/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"autos/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"autos/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"autos/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"autos/([^/]+)/embed/?$";s:38:"index.php?autos=$matches[1]&embed=true";s:26:"autos/([^/]+)/trackback/?$";s:32:"index.php?autos=$matches[1]&tb=1";s:46:"autos/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?autos=$matches[1]&feed=$matches[2]";s:41:"autos/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?autos=$matches[1]&feed=$matches[2]";s:34:"autos/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?autos=$matches[1]&paged=$matches[2]";s:41:"autos/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?autos=$matches[1]&cpage=$matches[2]";s:30:"autos/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?autos=$matches[1]&page=$matches[2]";s:22:"autos/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"autos/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"autos/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"autos/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"autos/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"autos/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=23&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(295, '_site_transient_timeout_browser_cb0f25941c7ee58acd15fece4d84c18b', '1511256760', 'yes'),
(296, '_site_transient_browser_cb0f25941c7ee58acd15fece4d84c18b', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:12:"62.0.3202.94";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'yes'),
(299, '_site_transient_timeout_theme_roots', '1510754324', 'yes'),
(300, '_site_transient_theme_roots', 'a:4:{s:7:"klunker";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'yes'),
(303, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:7:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:65:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.8.3.zip";s:6:"locale";s:5:"ru_RU";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.8.3.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.3";s:7:"version";s:5:"4.8.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.3.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.8.3-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.8.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.3";s:7:"version";s:5:"4.8.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}i:2;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.3.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.8.3.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.8.3-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.8.3-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.8.3";s:7:"version";s:5:"4.8.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:3;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.7.7.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.7.7.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.7.7-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.7.7-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.7.7";s:7:"version";s:5:"4.7.7";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:4;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.6.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.6.8.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.6.8-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.6.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.6.8";s:7:"version";s:5:"4.6.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:5;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:60:"https://downloads.wordpress.org/release/wordpress-4.5.11.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:60:"https://downloads.wordpress.org/release/wordpress-4.5.11.zip";s:10:"no_content";s:71:"https://downloads.wordpress.org/release/wordpress-4.5.11-no-content.zip";s:11:"new_bundled";s:72:"https://downloads.wordpress.org/release/wordpress-4.5.11-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:6:"4.5.11";s:7:"version";s:6:"4.5.11";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";s:9:"new_files";s:1:"1";}i:6;O:8:"stdClass":11:{s:8:"response";s:10:"autoupdate";s:8:"download";s:60:"https://downloads.wordpress.org/release/wordpress-4.4.12.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:60:"https://downloads.wordpress.org/release/wordpress-4.4.12.zip";s:10:"no_content";s:71:"https://downloads.wordpress.org/release/wordpress-4.4.12-no-content.zip";s:11:"new_bundled";s:72:"https://downloads.wordpress.org/release/wordpress-4.4.12-new-bundled.zip";s:7:"partial";s:70:"https://downloads.wordpress.org/release/wordpress-4.4.12-partial-2.zip";s:8:"rollback";s:71:"https://downloads.wordpress.org/release/wordpress-4.4.12-rollback-2.zip";}s:7:"current";s:6:"4.4.12";s:7:"version";s:6:"4.4.12";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:5:"4.4.2";s:9:"new_files";s:0:"";}}s:12:"last_checked";i:1510752528;s:15:"version_checked";s:5:"4.4.2";s:12:"translations";a:1:{i:0;a:7:{s:4:"type";s:4:"core";s:4:"slug";s:7:"default";s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.4.2";s:7:"updated";s:19:"2016-03-21 18:23:26";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.4.2/ru_RU.zip";s:10:"autoupdate";b:1;}}}', 'yes'),
(304, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1510752532;s:7:"checked";a:4:{s:7:"klunker";s:3:"1.0";s:13:"twentyfifteen";s:3:"1.4";s:14:"twentyfourteen";s:3:"1.6";s:13:"twentysixteen";s:3:"1.1";}s:8:"response";a:3:{s:13:"twentyfifteen";a:4:{s:5:"theme";s:13:"twentyfifteen";s:11:"new_version";s:3:"1.8";s:3:"url";s:43:"https://wordpress.org/themes/twentyfifteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentyfifteen.1.8.zip";}s:14:"twentyfourteen";a:4:{s:5:"theme";s:14:"twentyfourteen";s:11:"new_version";s:3:"2.0";s:3:"url";s:44:"https://wordpress.org/themes/twentyfourteen/";s:7:"package";s:60:"https://downloads.wordpress.org/theme/twentyfourteen.2.0.zip";}s:13:"twentysixteen";a:4:{s:5:"theme";s:13:"twentysixteen";s:11:"new_version";s:3:"1.3";s:3:"url";s:43:"https://wordpress.org/themes/twentysixteen/";s:7:"package";s:59:"https://downloads.wordpress.org/theme/twentysixteen.1.3.zip";}}s:12:"translations";a:0:{}}', 'yes'),
(305, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1510752530;s:8:"response";a:2:{s:19:"akismet/akismet.php";O:8:"stdClass":11:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"4.0.1";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.4.0.1.zip";s:5:"icons";a:3:{s:2:"1x";s:59:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272";s:2:"2x";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";s:7:"default";s:59:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272";}s:7:"banners";a:2:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";s:7:"default";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:6:"tested";s:3:"4.9";s:13:"compatibility";a:0:{}}s:61:"orbisius-child-theme-creator/orbisius-child-theme-creator.php";O:8:"stdClass":11:{s:2:"id";s:42:"w.org/plugins/orbisius-child-theme-creator";s:4:"slug";s:28:"orbisius-child-theme-creator";s:6:"plugin";s:61:"orbisius-child-theme-creator/orbisius-child-theme-creator.php";s:11:"new_version";s:5:"1.4.6";s:3:"url";s:59:"https://wordpress.org/plugins/orbisius-child-theme-creator/";s:7:"package";s:77:"https://downloads.wordpress.org/plugin/orbisius-child-theme-creator.1.4.6.zip";s:5:"icons";a:0:{}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}s:6:"tested";s:5:"4.8.3";s:13:"compatibility";a:0:{}}}s:12:"translations";a:0:{}s:9:"no_update";a:1:{s:45:"search-and-replace/inpsyde-search-replace.php";O:8:"stdClass":9:{s:2:"id";s:32:"w.org/plugins/search-and-replace";s:4:"slug";s:18:"search-and-replace";s:6:"plugin";s:45:"search-and-replace/inpsyde-search-replace.php";s:11:"new_version";s:5:"3.1.2";s:3:"url";s:49:"https://wordpress.org/plugins/search-and-replace/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/search-and-replace.3.1.2.zip";s:5:"icons";a:3:{s:2:"1x";s:71:"https://ps.w.org/search-and-replace/assets/icon-128x128.png?rev=1339190";s:2:"2x";s:71:"https://ps.w.org/search-and-replace/assets/icon-256x256.png?rev=1339190";s:7:"default";s:71:"https://ps.w.org/search-and-replace/assets/icon-256x256.png?rev=1339190";}s:7:"banners";a:3:{s:2:"2x";s:74:"https://ps.w.org/search-and-replace/assets/banner-1544x500.png?rev=1352307";s:2:"1x";s:73:"https://ps.w.org/search-and-replace/assets/banner-772x250.png?rev=1352307";s:7:"default";s:74:"https://ps.w.org/search-and-replace/assets/banner-1544x500.png?rev=1352307";}s:11:"banners_rtl";a:0:{}}}}', 'yes');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB AUTO_INCREMENT=481 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 6, '_edit_last', '1'),
(3, 6, '_edit_lock', '1510420118:1'),
(4, 6, 'manufacturer', 'Ford'),
(5, 6, 'model_year', '2001'),
(6, 6, 'production_end', '2005'),
(7, 6, 'engine_v', '1.8'),
(8, 6, 'engine_hp', '115'),
(9, 6, 'gearbox', 'MT'),
(10, 6, 'model_name', 'Focus'),
(11, 6, 'body_type', 'седан'),
(12, 8, '_edit_last', '1'),
(13, 8, '_edit_lock', '1510505199:1'),
(14, 8, 'body_type', 'sedan'),
(15, 8, 'engine_hp', '109'),
(16, 8, 'gearbox', 'AT'),
(17, 8, 'manufacturer', 'Nissan'),
(18, 8, 'model_name', 'Primera P12'),
(19, 8, 'model_year', '2002'),
(20, 8, 'shock_absorber_price', '11586'),
(21, 8, 'shock_absorber_price_2', '4151'),
(22, 8, 'strut_price', '11196'),
(23, 8, 'strut_price_2', '3057'),
(24, 8, 'lower_arm_price', '9225'),
(25, 8, 'lower_arm_price_2', '4753'),
(26, 8, 'lower_arm_bush_price', '0'),
(27, 8, 'lower_arm_large_bush_price', '0'),
(28, 8, 'front_wheel_bearing_price', '2066'),
(29, 8, 'front_wheel_bearing_price_2', '897'),
(30, 8, 'front_hub_price', '7980'),
(31, 8, 'front_hub_price_2', '2834'),
(32, 8, 'brake_disc_front_price', '5592'),
(33, 8, 'brake_disc_front_price_2', '2305'),
(34, 8, 'brake_pads_front_price', '4626'),
(35, 8, 'brake_pads_front_price_2', '2098'),
(36, 8, 'rear_bearing_price', '0'),
(37, 8, 'rear_hub_price', '10675'),
(38, 8, 'rear_hub_price_2', '1891'),
(39, 8, 'shock_absorber_rear_price', '6645'),
(40, 8, 'shock_absorber_rear_price_2', '2600'),
(41, 8, 'gearbox_parts_available', '1'),
(42, 8, 'steering_gear_price', '48133'),
(43, 8, 'steering_gear_parts_available', '0'),
(44, 8, 'hood_price', '22734'),
(45, 8, 'hood_price_2', '14733'),
(46, 8, 'headlamp_price', '13235'),
(47, 8, 'headlamp_price_2', '4858'),
(48, 8, 'front_bumper_price', '6846+11797+9189'),
(49, 9, '_edit_last', '1'),
(50, 9, '_edit_lock', '1510427933:1'),
(51, 9, 'body_type', 'hatchback'),
(52, 9, 'engine_hp', '112'),
(53, 9, 'gearbox', 'AT'),
(54, 9, 'model_name', 'SX4'),
(55, 9, 'manufacturer', 'Suzuki'),
(56, 9, 'model_year', '2007'),
(57, 9, 'shock_absorber_price', '8748'),
(58, 9, 'shock_absorber_price_2', '5134'),
(59, 9, 'strut_price', '7697'),
(60, 9, 'strut_price_2', '2195'),
(61, 9, 'front_wheel_bearing_price', '4373'),
(62, 9, 'front_wheel_bearing_price_2', '1652'),
(63, 9, 'brake_pads_front_price', '9605'),
(64, 9, 'brake_pads_front_price_2', '6370'),
(65, 10, '_edit_last', '1'),
(66, 10, '_edit_lock', '1510471904:1'),
(67, 10, 'body_type', 'Sedan'),
(68, 10, 'engine_hp', '110'),
(69, 10, 'manufacturer', 'Nissan'),
(70, 10, 'model_name', 'Tiida sedan'),
(71, 10, 'gearbox', 'AT'),
(72, 10, 'model_year', '2007'),
(73, 10, 'brake_disc_front_price', '3744'),
(74, 10, 'brake_disc_front_price_2', '1811'),
(75, 10, 'front_wheel_bearing_price', '0'),
(76, 10, 'front_hub_price', '6926'),
(77, 10, 'front_hub_price_2', '3648'),
(78, 10, 'gearbox', 'AT'),
(79, 10, 'gearbox_parts_available', '1'),
(80, 10, 'headlamp_price', '9458'),
(81, 10, 'headlamp_price_2', '5164'),
(82, 10, 'hood_price', '27765'),
(83, 10, 'hood_price_2', '6469'),
(84, 10, 'lower_arm_bush_price', '0'),
(85, 10, 'lower_arm_large_bush_price', '0'),
(86, 10, 'lower_arm_price', '5558'),
(87, 10, 'lower_arm_price_2', '2514'),
(88, 10, 'rear_bearing_price', '0'),
(89, 10, 'rear_hub_price', '7896'),
(90, 10, 'rear_hub_price_2', '2807'),
(91, 10, 'shock_absorber_price', '6298'),
(92, 10, 'shock_absorber_price', '6298'),
(93, 10, 'shock_absorber_price_2', '4140'),
(94, 10, 'shock_absorber_rear_price', '2464'),
(95, 10, 'steering_gear_parts_available', '1'),
(96, 10, 'steering_gear_price', '44792'),
(97, 10, 'strut_price', '6940'),
(98, 10, 'front_bumper_price', '11199+20858'),
(99, 19, '_edit_last', '1'),
(100, 19, '_edit_lock', '1510513701:1'),
(101, 19, '_car_data_manufacturer', ''),
(102, 19, '_car_data_model', ''),
(103, 19, '_car_data_model_year', ''),
(104, 19, '_car_data_body_type', ''),
(105, 19, '_car_data_engine_hp', ''),
(106, 19, '_car_data_gearbox_type', ''),
(107, 19, '_car_data_wheel_drive', ''),
(108, 19, '_car_data_front_shock_absorber_price', ''),
(109, 19, '_car_data_front_shock_absorber_price_2', ''),
(110, 19, '_car_data_front_shock_absorber_code', ''),
(111, 19, '_car_data_front_spring_price', ''),
(112, 19, '_car_data_front_spring_price_2', ''),
(113, 19, '_car_data_front_spring_code', ''),
(114, 19, '_car_data_front_bush_price', ''),
(115, 19, '_car_data_front_bush_code', ''),
(116, 19, '_car_data_front_large_bush_price', ''),
(117, 19, '_car_data_front_large_bush_code', ''),
(118, 19, '_car_data_front_lower_arm_price', ''),
(119, 19, '_car_data_front_lower_arm_price_2', ''),
(120, 19, '_car_data_front_lower_arm_code', ''),
(121, 19, '_car_data_front_brake_disc_price', ''),
(122, 19, '_car_data_front_brake_disc_price_2', ''),
(123, 19, '_car_data_front_brake_disc_code', ''),
(124, 19, '_car_data_front_brake_pads_price', ''),
(125, 19, '_car_data_front_brake_pads_price_2', ''),
(126, 19, '_car_data_front_hub_bearing_price', ''),
(127, 19, '_car_data_front_hub_bearing_code', ''),
(128, 19, '_car_data_front_hub_price', ''),
(129, 19, '_car_data_front_hub_price_2', ''),
(130, 19, '_car_data_front_hub_code', ''),
(131, 19, '_car_data_rear_shock_absorber_price', ''),
(132, 19, '_car_data_rear_shock_absorber_price_2', ''),
(133, 19, '_car_data_rear_shock_absorber_code', ''),
(134, 19, '_car_data_rear_spring_price', ''),
(135, 19, '_car_data_rear_spring_price_2', ''),
(136, 19, '_car_data_rear_spring_code', ''),
(137, 19, '_car_data_rear_hub_bearing_price', ''),
(138, 19, '_car_data_rear_hub_bearing_code', ''),
(139, 19, '_car_data_rear_hub_price', ''),
(140, 19, '_car_data_rear_hub_price_2', ''),
(141, 19, '_car_data_rear_hub_code', ''),
(142, 19, '_car_data_front_bumper_price', ''),
(143, 19, '_car_data_front_bumper_code', ''),
(144, 19, '_car_data_front_fender_price', ''),
(145, 19, '_car_data_front_fender_price_2', ''),
(146, 19, '_car_data_front_fender_code', ''),
(147, 19, '_car_data_wind_screen_price', ''),
(148, 19, '_car_data_wind_screen_price_2', ''),
(149, 19, '_car_data_wind_screen_code', ''),
(150, 19, '_car_data_steering_rack', ''),
(151, 19, '_car_data_gearbox', ''),
(152, 19, '_wp_trash_meta_status', 'publish'),
(153, 19, '_wp_trash_meta_time', '1510513844'),
(154, 20, '_edit_last', '1'),
(155, 20, '_edit_lock', '1510596095:1'),
(156, 20, '_car_data_manufacturer', 'Nissan'),
(157, 20, '_car_data_model', 'Primera'),
(158, 20, '_car_data_model_year', '2002'),
(159, 20, '_car_data_body_type', 'hatchback'),
(160, 20, '_car_data_engine_hp', '110'),
(161, 20, '_car_data_gearbox_type', 'hydro'),
(162, 20, '_car_data_wheel_drive', '2wd'),
(163, 20, '_car_data_front_shock_absorber_price', '11 586'),
(164, 20, '_car_data_front_shock_absorber_price_2', '4 151'),
(165, 20, '_car_data_front_shock_absorber_code', '54302-AV425'),
(166, 20, '_car_data_front_spring_price', '11 196'),
(167, 20, '_car_data_front_spring_price_2', '2 498'),
(168, 20, '_car_data_front_spring_code', '54010-AV611'),
(169, 20, '_car_data_front_bush_price', '0'),
(170, 20, '_car_data_front_bush_code', ''),
(171, 20, '_car_data_front_large_bush_price', ''),
(172, 20, '_car_data_front_large_bush_code', ''),
(173, 20, '_car_data_front_lower_arm_price', '9 225'),
(174, 20, '_car_data_front_lower_arm_price_2', '2 947'),
(175, 20, '_car_data_front_lower_arm_code', '54501-AV600'),
(176, 20, '_car_data_front_brake_disc_price', '5 592'),
(177, 20, '_car_data_front_brake_disc_price_2', '1 673'),
(178, 20, '_car_data_front_brake_disc_code', '40206-4U107'),
(179, 20, '_car_data_front_brake_pads_price', '2 066'),
(180, 20, '_car_data_front_brake_pads_price_2', '1 235'),
(181, 20, '_car_data_front_hub_bearing_price', '1235'),
(182, 20, '_car_data_front_hub_bearing_code', '40210-2Y000'),
(183, 20, '_car_data_front_hub_price', '7 980'),
(184, 20, '_car_data_front_hub_price_2', '2 834'),
(185, 20, '_car_data_front_hub_code', '40202-BU000'),
(186, 20, '_car_data_rear_shock_absorber_price', '3 932'),
(187, 20, '_car_data_rear_shock_absorber_price_2', '3 756'),
(188, 20, '_car_data_rear_shock_absorber_code', '56210-BA025'),
(189, 20, '_car_data_rear_spring_price', '6 783'),
(190, 20, '_car_data_rear_spring_price_2', '1 364'),
(191, 20, '_car_data_rear_spring_code', '55020-AV600'),
(192, 20, '_car_data_rear_hub_bearing_price', '0'),
(193, 20, '_car_data_rear_hub_bearing_code', ''),
(194, 20, '_car_data_rear_hub_price', '10 675'),
(195, 20, '_car_data_rear_hub_price_2', '1 891'),
(196, 20, '_car_data_rear_hub_code', '43200-AV700'),
(197, 20, '_car_data_front_bumper_price', '9 193+5 477+1 891'),
(198, 20, '_car_data_front_bumper_code', '62022-AU440+62090-AU300+62254-AU300'),
(199, 20, '_car_data_front_fender_price', '11 352'),
(200, 20, '_car_data_front_fender_price_2', '8 660'),
(201, 20, '_car_data_front_fender_code', '63101-AV630'),
(202, 20, '_car_data_wind_screen_price', '30 319'),
(203, 20, '_car_data_wind_screen_price_2', '4 235'),
(204, 20, '_car_data_wind_screen_code', '72700-AV715'),
(205, 20, '_car_data_steering_rack', '0'),
(206, 20, '_car_data_gearbox', '1'),
(207, 21, '_edit_last', '1'),
(208, 21, '_edit_lock', '1510595755:1'),
(209, 21, '_car_data_manufacturer', 'Nissan'),
(210, 21, '_car_data_model', 'Almera'),
(211, 21, '_car_data_model_year', '2003'),
(212, 21, '_car_data_body_type', 'sedan'),
(213, 21, '_car_data_engine_hp', '118'),
(214, 21, '_car_data_gearbox_type', 'hydro'),
(215, 21, '_car_data_wheel_drive', '2wd'),
(216, 21, '_car_data_front_shock_absorber_price', '6 493'),
(217, 21, '_car_data_front_shock_absorber_price_2', '3 185'),
(218, 21, '_car_data_front_shock_absorber_code', 'E4302-BM425'),
(219, 21, '_car_data_front_spring_price', '10 561'),
(220, 21, '_car_data_front_spring_price_2', '1 607'),
(221, 21, '_car_data_front_spring_code', '54010-BM401'),
(222, 21, '_car_data_front_bush_price', '0'),
(223, 21, '_car_data_front_bush_code', ''),
(224, 21, '_car_data_front_large_bush_price', ''),
(225, 21, '_car_data_front_large_bush_code', ''),
(226, 21, '_car_data_front_lower_arm_price', '7 330'),
(227, 21, '_car_data_front_lower_arm_price_2', '4 300'),
(228, 21, '_car_data_front_lower_arm_code', '54500-BM410'),
(229, 21, '_car_data_front_brake_disc_price', '2 997'),
(230, 21, '_car_data_front_brake_disc_price_2', '2 114'),
(231, 21, '_car_data_front_brake_disc_code', '40206-2F501'),
(232, 21, '_car_data_front_brake_pads_price', '2 885'),
(233, 21, '_car_data_front_brake_pads_price_2', '1 863'),
(234, 21, '_car_data_front_hub_bearing_price', '1 319'),
(235, 21, '_car_data_front_hub_bearing_code', '40210-4M400'),
(236, 21, '_car_data_front_hub_price', '0'),
(237, 21, '_car_data_front_hub_price_2', ''),
(238, 21, '_car_data_front_hub_code', ''),
(239, 21, '_car_data_rear_shock_absorber_price', '3 465'),
(240, 21, '_car_data_rear_shock_absorber_price_2', '2 106'),
(241, 21, '_car_data_rear_shock_absorber_code', ''),
(242, 21, '_car_data_rear_spring_price', '6 576'),
(243, 21, '_car_data_rear_spring_price_2', '1 302'),
(244, 21, '_car_data_rear_spring_code', '55020-BM410'),
(245, 21, '_car_data_rear_hub_bearing_price', '0'),
(246, 21, '_car_data_rear_hub_bearing_code', ''),
(247, 21, '_car_data_rear_hub_price', '10 912'),
(248, 21, '_car_data_rear_hub_price_2', '1 582'),
(249, 21, '_car_data_rear_hub_code', '43200-9F510'),
(250, 21, '_car_data_front_bumper_price', '4 232+748'),
(251, 21, '_car_data_front_bumper_code', '62254-BN700+62022-BN700'),
(252, 21, '_car_data_front_fender_price', '8 982'),
(253, 21, '_car_data_front_fender_price_2', '3 078'),
(254, 21, '_car_data_front_fender_code', '63100-BN730'),
(255, 21, '_car_data_wind_screen_price', '11 162'),
(256, 21, '_car_data_wind_screen_price_2', '3 332'),
(257, 21, '_car_data_wind_screen_code', '72700-BM400'),
(258, 21, '_car_data_steering_rack', '0'),
(259, 21, '_car_data_gearbox', '1'),
(260, 21, '_car_data_fuel_pump_price', '15 589'),
(261, 21, '_car_data_fuel_pump_price_2', '3 295'),
(262, 21, '_car_data_fuel_pump_code', '17040-BN805'),
(263, 21, '_car_data_headlamp_price', '19 018'),
(264, 21, '_car_data_headlamp_price_2', '4 084'),
(265, 21, '_car_data_headlamp_code', '26010-BN67A'),
(266, 21, '_car_data_hood_price', '26 322'),
(267, 21, '_car_data_hood_price_2', '7 051'),
(268, 21, '_car_data_hood_code', '65100-BN730'),
(269, 20, '_car_data_headlamp_price', '13 235'),
(270, 20, '_car_data_headlamp_price_2', '4 858'),
(271, 20, '_car_data_headlamp_code', '26010-AU800'),
(272, 20, '_car_data_hood_price', '22 734'),
(273, 20, '_car_data_hood_price_2', '14 733'),
(274, 20, '_car_data_hood_code', '65100-AV630'),
(275, 20, '_car_data_fuel_pump_price', '14 446'),
(276, 20, '_car_data_fuel_pump_price_2', '1 942'),
(277, 20, '_car_data_fuel_pump_code', '17040-AV705'),
(278, 20, '_car_data_front_brake_pads_code', '41060-AV126'),
(279, 22, '_edit_last', '1'),
(280, 22, '_edit_lock', '1510596045:1'),
(281, 22, '_car_data_manufacturer', 'Kia'),
(282, 22, '_car_data_model', 'Rio'),
(283, 22, '_car_data_model_year', '2012'),
(284, 22, '_car_data_body_type', 'hatchback'),
(285, 22, '_car_data_engine_hp', '123'),
(286, 22, '_car_data_gearbox_type', 'hydro'),
(287, 22, '_car_data_wheel_drive', '2wd'),
(288, 22, '_car_data_front_shock_absorber_price', '6 814'),
(289, 22, '_car_data_front_shock_absorber_price_2', '3 201'),
(290, 22, '_car_data_front_shock_absorber_code', '54650-4Y100'),
(291, 22, '_car_data_front_spring_price', '3 926'),
(292, 22, '_car_data_front_spring_price_2', '1 139'),
(293, 22, '_car_data_front_spring_code', '54630-4L102'),
(294, 22, '_car_data_front_bush_price', '618'),
(295, 22, '_car_data_front_bush_code', '54530-25000'),
(296, 22, '_car_data_front_large_bush_price', ''),
(297, 22, '_car_data_front_large_bush_code', ''),
(298, 22, '_car_data_front_lower_arm_price', '4 667'),
(299, 22, '_car_data_front_lower_arm_price_2', '2 389'),
(300, 22, '_car_data_front_lower_arm_code', '54501-4L000'),
(301, 22, '_car_data_front_brake_disc_price', '4 003'),
(302, 22, '_car_data_front_brake_disc_price_2', '1 586'),
(303, 22, '_car_data_front_brake_disc_code', '51712-0U000'),
(304, 22, '_car_data_front_brake_pads_price', '2 660'),
(305, 22, '_car_data_front_brake_pads_price_2', '1 768'),
(306, 22, '_car_data_front_brake_pads_code', '58101-4LA00'),
(307, 22, '_car_data_front_hub_bearing_price', '1 226'),
(308, 22, '_car_data_front_hub_bearing_code', '51720-02000'),
(309, 22, '_car_data_front_hub_price', '0'),
(310, 22, '_car_data_front_hub_price_2', ''),
(311, 22, '_car_data_front_hub_code', ''),
(312, 22, '_car_data_rear_shock_absorber_price', '2 817'),
(313, 22, '_car_data_rear_shock_absorber_price_2', '1 909'),
(314, 22, '_car_data_rear_shock_absorber_code', '55300-4L002'),
(315, 22, '_car_data_rear_spring_price', '2 236'),
(316, 22, '_car_data_rear_spring_price_2', '1 171'),
(317, 22, '_car_data_rear_spring_code', '55330-4L001'),
(318, 22, '_car_data_rear_hub_bearing_price', '0'),
(319, 22, '_car_data_rear_hub_bearing_code', ''),
(320, 22, '_car_data_rear_hub_price', '4 520'),
(321, 22, '_car_data_rear_hub_price_2', '2 196'),
(322, 22, '_car_data_rear_hub_code', '52750-0U000'),
(323, 22, '_car_data_headlamp_price', '11 469'),
(324, 22, '_car_data_headlamp_price_2', '3 418'),
(325, 22, '_car_data_headlamp_code', '92101-4X000'),
(326, 22, '_car_data_hood_price', '17 110'),
(327, 22, '_car_data_hood_price_2', '6 149'),
(328, 22, '_car_data_hood_code', '66400-4Y000'),
(329, 22, '_car_data_front_bumper_price', '7 076+2 104+732+2 750'),
(330, 22, '_car_data_front_bumper_code', '86511-4Y000+86561-4Y000+86524-4Y000+86580-4Y000'),
(331, 22, '_car_data_front_fender_price', '7 082'),
(332, 22, '_car_data_front_fender_price_2', '1 974'),
(333, 22, '_car_data_front_fender_code', '66321-4Y000'),
(334, 22, '_car_data_wind_screen_price', '15 792'),
(335, 22, '_car_data_wind_screen_price_2', '3 507'),
(336, 22, '_car_data_wind_screen_code', '86110-4L010'),
(337, 22, '_car_data_fuel_pump_price', '4 224'),
(338, 22, '_car_data_fuel_pump_price_2', '661'),
(339, 22, '_car_data_fuel_pump_code', '31111-1R000'),
(340, 22, '_car_data_steering_rack', '1'),
(341, 22, '_car_data_gearbox', '1'),
(342, 22, '_car_data_drive_total', '24300'),
(343, 20, '_car_data_drive_total', '59595'),
(344, 23, '_edit_last', '1'),
(345, 23, '_edit_lock', '1510595951:1'),
(346, 21, '_car_data_front_brake_pads_code', ''),
(347, 21, '_car_data_drive_total', '41626'),
(348, 21, '_car_data_body_total', '69716'),
(349, 22, '_car_data_body_total', '58529'),
(350, 20, '_car_data_body_total', '86833'),
(351, 33, '_edit_last', '1'),
(352, 33, '_edit_lock', '1510597458:1'),
(353, 33, '_car_data_manufacturer', 'Lada'),
(354, 33, '_car_data_model', 'Vesta'),
(355, 33, '_car_data_model_year', '2015'),
(356, 33, '_car_data_body_type', 'sedan'),
(357, 33, '_car_data_engine_hp', '106'),
(358, 33, '_car_data_gearbox_type', 'singleclutch'),
(359, 33, '_car_data_wheel_drive', '2wd'),
(360, 33, '_car_data_front_shock_absorber_price', '3895'),
(361, 33, '_car_data_front_shock_absorber_price_2', '2516'),
(362, 33, '_car_data_front_shock_absorber_code', '8450006745'),
(363, 33, '_car_data_front_spring_price', '1985'),
(364, 33, '_car_data_front_spring_price_2', ''),
(365, 33, '_car_data_front_spring_code', '8450006725'),
(366, 33, '_car_data_front_bush_price', '690'),
(367, 33, '_car_data_front_bush_code', '8450006742'),
(368, 33, '_car_data_front_large_bush_price', ''),
(369, 33, '_car_data_front_large_bush_code', ''),
(370, 33, '_car_data_front_lower_arm_price', '2753'),
(371, 33, '_car_data_front_lower_arm_price_2', ''),
(372, 33, '_car_data_front_lower_arm_code', '8450006735'),
(373, 33, '_car_data_front_brake_disc_price', '3042'),
(374, 33, '_car_data_front_brake_disc_price_2', '1086'),
(375, 33, '_car_data_front_brake_disc_code', '8450006845'),
(376, 33, '_car_data_front_brake_pads_price', '1523'),
(377, 33, '_car_data_front_brake_pads_price_2', '705'),
(378, 33, '_car_data_front_brake_pads_code', '410608481R'),
(379, 33, '_car_data_front_hub_bearing_price', '957'),
(380, 33, '_car_data_front_hub_bearing_code', '7700432405'),
(381, 33, '_car_data_front_hub_price', '0'),
(382, 33, '_car_data_front_hub_price_2', ''),
(383, 33, '_car_data_front_hub_code', ''),
(384, 33, '_car_data_rear_shock_absorber_price', '2643'),
(385, 33, '_car_data_rear_shock_absorber_price_2', '2011'),
(386, 33, '_car_data_rear_shock_absorber_code', '8450006786'),
(387, 33, '_car_data_rear_spring_price', '1953'),
(388, 33, '_car_data_rear_spring_price_2', '612'),
(389, 33, '_car_data_rear_spring_code', '8450006758'),
(390, 33, '_car_data_rear_hub_bearing_price', '2236'),
(391, 33, '_car_data_rear_hub_bearing_code', '8200600646'),
(392, 33, '_car_data_rear_hub_price', '0'),
(393, 33, '_car_data_rear_hub_price_2', ''),
(394, 33, '_car_data_rear_hub_code', ''),
(395, 33, '_car_data_headlamp_price', '13287'),
(396, 33, '_car_data_headlamp_price_2', ''),
(397, 33, '_car_data_headlamp_code', '8450006952'),
(398, 33, '_car_data_hood_price', '10742'),
(399, 33, '_car_data_hood_price_2', ''),
(400, 33, '_car_data_hood_code', '8450039378'),
(401, 33, '_car_data_front_bumper_price', '4861+855+855+933+933+1834+1048'),
(402, 33, '_car_data_front_bumper_code', '8450008923+8450008670+8450008923+8450008670+8450006666+8450008960+8450006689'),
(403, 33, '_car_data_front_fender_price', '4792'),
(404, 33, '_car_data_front_fender_price_2', ''),
(405, 33, '_car_data_front_fender_code', '8450039386'),
(406, 33, '_car_data_wind_screen_price', '7430'),
(407, 33, '_car_data_wind_screen_price_2', '6087'),
(408, 33, '_car_data_wind_screen_code', '8450007323'),
(409, 33, '_car_data_fuel_pump_price', '6941'),
(410, 33, '_car_data_fuel_pump_price_2', ''),
(411, 33, '_car_data_fuel_pump_code', '21800113900900'),
(412, 33, '_car_data_steering_rack', '0'),
(413, 33, '_car_data_gearbox', '1'),
(414, 33, '_car_data_drive_total', '18924'),
(415, 33, '_car_data_body_total', '41112'),
(416, 34, '_edit_last', '1'),
(417, 34, '_edit_lock', '1510599694:1'),
(418, 34, '_car_data_manufacturer', 'Opel'),
(419, 34, '_car_data_model', 'Astra'),
(420, 34, '_car_data_model_year', '2004'),
(421, 34, '_car_data_body_type', 'sedan'),
(422, 34, '_car_data_engine_hp', '140'),
(423, 34, '_car_data_gearbox_type', 'hydro'),
(424, 34, '_car_data_wheel_drive', '2wd'),
(425, 34, '_car_data_front_shock_absorber_price', '6 284'),
(426, 34, '_car_data_front_shock_absorber_price_2', '1 893'),
(427, 34, '_car_data_front_shock_absorber_code', '93195915'),
(428, 34, '_car_data_front_spring_price', '5 225'),
(429, 34, '_car_data_front_spring_price_2', '995'),
(430, 34, '_car_data_front_spring_code', '93179681'),
(431, 34, '_car_data_front_bush_price', '3 265'),
(432, 34, '_car_data_front_bush_code', '90512982'),
(433, 34, '_car_data_front_large_bush_price', ''),
(434, 34, '_car_data_front_large_bush_code', ''),
(435, 34, '_car_data_front_lower_arm_price', '11 533'),
(436, 34, '_car_data_front_lower_arm_price_2', '2 094'),
(437, 34, '_car_data_front_lower_arm_code', '24454478'),
(438, 34, '_car_data_front_brake_disc_price', '11 307/2'),
(439, 34, '_car_data_front_brake_disc_price_2', '2 402'),
(440, 34, '_car_data_front_brake_disc_code', '93197592'),
(441, 34, '_car_data_front_brake_pads_price', '4 753'),
(442, 34, '_car_data_front_brake_pads_price_2', '1 994'),
(443, 34, '_car_data_front_brake_pads_code', '93181189'),
(444, 34, '_car_data_front_hub_bearing_price', '0'),
(445, 34, '_car_data_front_hub_bearing_code', ''),
(446, 34, '_car_data_front_hub_price', '17 186'),
(447, 34, '_car_data_front_hub_price_2', '6 417'),
(448, 34, '_car_data_front_hub_code', '93178651'),
(449, 34, '_car_data_rear_shock_absorber_price', '5 499'),
(450, 34, '_car_data_rear_shock_absorber_price_2', '1 717'),
(451, 34, '_car_data_rear_shock_absorber_code', '93178642'),
(452, 34, '_car_data_rear_spring_price', '11 022'),
(453, 34, '_car_data_rear_spring_price_2', '2 941'),
(454, 34, '_car_data_rear_spring_code', '93191005'),
(455, 34, '_car_data_rear_hub_bearing_price', '0'),
(456, 34, '_car_data_rear_hub_bearing_code', ''),
(457, 34, '_car_data_rear_hub_price', '15 765'),
(458, 34, '_car_data_rear_hub_price_2', '7 334'),
(459, 34, '_car_data_rear_hub_code', '93178626'),
(460, 34, '_car_data_headlamp_price', '11 319'),
(461, 34, '_car_data_headlamp_price_2', '5 090'),
(462, 34, '_car_data_headlamp_code', '93178636'),
(463, 34, '_car_data_hood_price', '37 353'),
(464, 34, '_car_data_hood_price_2', '6 205'),
(465, 34, '_car_data_hood_code', '93178717'),
(466, 34, '_car_data_front_bumper_price', '20 133+4 339+611+611'),
(467, 34, '_car_data_front_bumper_code', '13247248+13247248+24460258+13247248'),
(468, 34, '_car_data_front_fender_price', '9 005'),
(469, 34, '_car_data_front_fender_price_2', '2 550'),
(470, 34, '_car_data_front_fender_code', '93178667'),
(471, 34, '_car_data_wind_screen_price', '19 329'),
(472, 34, '_car_data_wind_screen_price_2', '10 535'),
(473, 34, '_car_data_wind_screen_code', '13220436'),
(474, 34, '_car_data_fuel_pump_price', '25 042'),
(475, 34, '_car_data_fuel_pump_price_2', '5 632'),
(476, 34, '_car_data_fuel_pump_code', '93188874'),
(477, 34, '_car_data_steering_rack', '0'),
(478, 34, '_car_data_gearbox', '1'),
(479, 34, '_car_data_drive_total', '81727'),
(480, 34, '_car_data_body_total', '97139');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-03-02 15:38:51', '2016-03-02 12:38:51', 'Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите её, затем пишите!', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2016-03-02 15:38:51', '2016-03-02 12:38:51', '', 0, 'http://klunkerlocal.ru/wordpress/?p=1', 0, 'post', '', 1),
(2, 1, '2016-03-02 15:38:51', '2016-03-02 12:38:51', 'Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:\n\n<blockquote>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</blockquote>\n\n...или так:\n\n<blockquote>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</blockquote>\n\nПерейдите <a href="http://klunkerlocal.ru/wordpress/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2016-03-02 15:38:51', '2016-03-02 12:38:51', '', 0, 'http://klunkerlocal.ru/wordpress/?page_id=2', 0, 'page', '', 0),
(6, 1, '2016-03-02 17:04:08', '2016-03-02 14:04:08', 'Lorem ipum content about ford focus', 'Ford Focus 2001', '', 'publish', 'closed', 'closed', '', 'ford-focus-2001', '', '', '2016-03-02 17:19:35', '2016-03-02 14:19:35', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=product&#038;p=6', 0, 'product', '', 0),
(7, 1, '2017-11-11 20:04:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-11-11 20:04:34', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?p=7', 0, 'post', '', 0),
(8, 1, '2017-11-11 21:17:12', '2017-11-11 18:17:12', '', 'Nissan Primera P12 EU', '', 'publish', 'closed', 'closed', '', 'nissan-primera-p12-eu', '', '', '2017-11-11 21:17:12', '2017-11-11 18:17:12', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=product&#038;p=8', 0, 'product', '', 0),
(9, 1, '2017-11-11 22:21:13', '2017-11-11 19:21:13', '', 'Suzuki SX4 2007', '', 'publish', 'closed', 'closed', '', 'suzuki-sx4-2007', '', '', '2017-11-11 22:21:13', '2017-11-11 19:21:13', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=product&#038;p=9', 0, 'product', '', 0),
(10, 1, '2017-11-11 22:52:56', '2017-11-11 19:52:56', '', 'Nissan Tiida Sedan C11', '', 'publish', 'closed', 'closed', '', 'nissan-tiida-sedan-c11', '', '', '2017-11-11 22:52:56', '2017-11-11 19:52:56', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=product&#038;p=10', 0, 'product', '', 0),
(11, 1, '2017-11-12 19:49:17', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 19:49:17', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=11', 0, 'autos', '', 0),
(12, 1, '2017-11-12 20:18:11', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:18:11', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=12', 0, 'autos', '', 0),
(13, 1, '2017-11-12 20:24:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:24:45', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=13', 0, 'autos', '', 0),
(14, 1, '2017-11-12 20:25:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:25:34', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=14', 0, 'autos', '', 0),
(15, 1, '2017-11-12 20:27:20', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:27:20', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=15', 0, 'autos', '', 0),
(16, 1, '2017-11-12 20:35:15', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:35:15', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=16', 0, 'autos', '', 0),
(17, 1, '2017-11-12 20:40:26', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:40:26', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=17', 0, 'autos', '', 0),
(18, 1, '2017-11-12 20:41:44', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-11-12 20:41:44', '0000-00-00 00:00:00', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&p=18', 0, 'autos', '', 0),
(19, 1, '2017-11-12 20:51:16', '2017-11-12 17:51:16', '', 'sdkmldskmf', '', 'trash', 'closed', 'closed', '', 'sdkmldskmf', '', '', '2017-11-12 22:10:44', '2017-11-12 19:10:44', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=19', 0, 'autos', '', 0),
(20, 1, '2017-11-12 22:53:05', '2017-11-12 19:53:05', '', 'Nissan Primera P12 2002', '', 'publish', 'closed', 'closed', '', 'nissan-primera-p12-2002', '', '', '2017-11-13 21:03:56', '2017-11-13 18:03:56', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=20', 0, 'autos', '', 0),
(21, 1, '2017-11-12 23:20:33', '2017-11-12 20:20:33', '', 'Nissan Almera N16 2003', '', 'publish', 'closed', 'closed', '', 'nissan-almera-n16', '', '', '2017-11-13 20:58:15', '2017-11-13 17:58:15', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=21', 0, 'autos', '', 0),
(22, 1, '2017-11-13 19:57:06', '2017-11-13 16:57:06', '', 'Kia Rio 2012', '', 'publish', 'closed', 'closed', '', 'kia-rio-2012', '', '', '2017-11-13 21:03:03', '2017-11-13 18:03:03', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=22', 0, 'autos', '', 0),
(23, 1, '2017-11-13 20:45:14', '2017-11-13 17:45:14', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<h4 style="text-align: center;">&nbsp;</h4>\r\n<h4 style="text-align: center;"><a href="autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-11-13 21:01:30', '2017-11-13 18:01:30', '', 0, 'http://klunkerlocal.ru/wordpress/?page_id=23', 0, 'page', '', 0),
(24, 1, '2017-11-13 20:45:14', '2017-11-13 17:45:14', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:45:14', '2017-11-13 17:45:14', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2017-11-13 20:54:51', '2017-11-13 17:54:51', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<p style="text-align: center;"><a href="/autos">Автомобили</a></p>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:54:51', '2017-11-13 17:54:51', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2017-11-13 20:55:15', '2017-11-13 17:55:15', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<h4 style="text-align: center;"><a href="/autos">Автомобили</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:55:15', '2017-11-13 17:55:15', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2017-11-13 20:56:07', '2017-11-13 17:56:07', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<h4 style="text-align: center;"><a href="http://autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:56:07', '2017-11-13 17:56:07', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2017-11-13 20:56:27', '2017-11-13 17:56:27', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<br/>\r\n<h4 style="text-align: center;"><a href="http://autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:56:27', '2017-11-13 17:56:27', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2017-11-13 20:56:49', '2017-11-13 17:56:49', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<br/><br/>\r\n<h4 style="text-align: center;"><a href="http://autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:56:49', '2017-11-13 17:56:49', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2017-11-13 20:57:24', '2017-11-13 17:57:24', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<h4 style="text-align: center;">&nbsp;</h4>\r\n<h4 style="text-align: center;"><a href="http://autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 20:57:24', '2017-11-13 17:57:24', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-11-13 20:58:29', '2017-11-13 17:58:29', '<h2 style="text-align: center;">Что выбрать?</h2>\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\n<h4 style="text-align: center;">&nbsp;</h4>\n<h4 style="text-align: center;"><a href="autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-autosave-v1', '', '', '2017-11-13 20:58:29', '2017-11-13 17:58:29', '', 23, 'http://klunkerlocal.ru/wordpress/23-autosave-v1/', 0, 'revision', '', 0),
(32, 1, '2017-11-13 21:01:30', '2017-11-13 18:01:30', '<h2 style="text-align: center;">Что выбрать?</h2>\r\n<h3 style="text-align: center;">Бюджетную рабочую лошадку или авто мечты постарше?</h3>\r\n<h4 style="text-align: center;">&nbsp;</h4>\r\n<h4 style="text-align: center;"><a href="autos">АВТОМОБИЛИ</a></h4>', 'Главная', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-11-13 21:01:30', '2017-11-13 18:01:30', '', 23, 'http://klunkerlocal.ru/wordpress/23-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2017-11-13 21:25:22', '2017-11-13 18:25:22', '', 'Lada Vesta 2015', '', 'publish', 'closed', 'closed', '', 'lada-vesta-2015', '', '', '2017-11-13 21:26:39', '2017-11-13 18:26:39', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=33', 0, 'autos', '', 0),
(34, 1, '2017-11-13 22:03:52', '2017-11-13 19:03:52', '', 'Opel Astra H 2004', '', 'publish', 'closed', 'closed', '', 'opel-astra-h-2004', '', '', '2017-11-13 22:03:52', '2017-11-13 19:03:52', '', 0, 'http://klunkerlocal.ru/wordpress/?post_type=autos&#038;p=34', 0, 'autos', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Класс C', '%d0%ba%d0%bb%d0%b0%d1%81%d1%81-c', 0),
(3, 'германия', '%d0%b3%d0%b5%d1%80%d0%bc%d0%b0%d0%bd%d0%b8%d1%8f', 0),
(4, 'европа', '%d0%b5%d0%b2%d1%80%d0%be%d0%bf%d0%b0', 0),
(5, 'форд', '%d1%84%d0%be%d1%80%d0%b4', 0),
(6, 'Класс B', '%d0%ba%d0%bb%d0%b0%d1%81%d1%81-b', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(6, 2, 0),
(6, 3, 0),
(6, 4, 0),
(6, 5, 0),
(21, 2, 0),
(22, 6, 0),
(33, 2, 0),
(34, 2, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'category', '', 0, 3),
(3, 3, 'post_tag', '', 0, 1),
(4, 4, 'post_tag', '', 0, 1),
(5, 5, 'post_tag', '', 0, 1),
(6, 6, 'category', '', 0, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'wpadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:2:{s:64:"622c1a4b9e132255795c41e756a5bb467e164737ea10a2947f564c2b6aefc4ee";a:4:{s:10:"expiration";i:1511629471;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.89 Safari/537.36";s:5:"login";i:1510419871;}s:64:"f435cca3c0e5d0e39cc90745b534a73f1010c7bb2bf03d4f55987f7597e7300f";a:4:{s:10:"expiration";i:1511846310;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.89 Safari/537.36";s:5:"login";i:1510636710;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '7'),
(16, 1, 'closedpostboxes_auto', 'a:1:{i:0;s:7:"slugdiv";}'),
(17, 1, 'metaboxhidden_auto', 'a:0:{}'),
(18, 1, 'wp_user-settings', 'editor=html&hidetb=1&wplink=1'),
(19, 1, 'wp_user-settings-time', '1510595783'),
(20, 1, 'closedpostboxes_post', 'a:0:{}'),
(21, 1, 'metaboxhidden_post', 'a:5:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(22, 1, 'closedpostboxes_autos', 'a:0:{}'),
(23, 1, 'metaboxhidden_autos', 'a:1:{i:0;s:7:"slugdiv";}');

-- --------------------------------------------------------

--
-- Структура таблицы `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'wpadmin', '$P$BzRdQzYnNaojNzLl.THK9kj0q99DNC/', 'wpadmin', 'alexander.palshin@gmail.com', '', '2016-03-02 12:38:50', '', 0, 'wpadmin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Индексы таблицы `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Индексы таблицы `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Индексы таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Индексы таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Индексы таблицы `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Индексы таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Индексы таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Индексы таблицы `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=306;
--
-- AUTO_INCREMENT для таблицы `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=481;
--
-- AUTO_INCREMENT для таблицы `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT для таблицы `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT для таблицы `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
